// generated from rosidl_generator_c/resource/idl.h.em
// with input from openmx_interfaces:srv/InverseKinematics.idl
// generated code does not contain a copyright notice

#ifndef OPENMX_INTERFACES__SRV__INVERSE_KINEMATICS_H_
#define OPENMX_INTERFACES__SRV__INVERSE_KINEMATICS_H_

#include "openmx_interfaces/srv/detail/inverse_kinematics__struct.h"
#include "openmx_interfaces/srv/detail/inverse_kinematics__functions.h"
#include "openmx_interfaces/srv/detail/inverse_kinematics__type_support.h"

#endif  // OPENMX_INTERFACES__SRV__INVERSE_KINEMATICS_H_
