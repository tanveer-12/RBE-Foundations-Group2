// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OPENMX_INTERFACES__SRV__INVERSE_KINEMATICS_HPP_
#define OPENMX_INTERFACES__SRV__INVERSE_KINEMATICS_HPP_

#include "openmx_interfaces/srv/detail/inverse_kinematics__struct.hpp"
#include "openmx_interfaces/srv/detail/inverse_kinematics__builder.hpp"
#include "openmx_interfaces/srv/detail/inverse_kinematics__traits.hpp"
#include "openmx_interfaces/srv/detail/inverse_kinematics__type_support.hpp"

#endif  // OPENMX_INTERFACES__SRV__INVERSE_KINEMATICS_HPP_
