# generated from rosidl_generator_py/resource/_idl.py.em
# with input from openmx_interfaces:srv/InverseKinematics.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_InverseKinematics_Request(type):
    """Metaclass of message 'InverseKinematics_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('openmx_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'openmx_interfaces.srv.InverseKinematics_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__inverse_kinematics__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__inverse_kinematics__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__inverse_kinematics__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__inverse_kinematics__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__inverse_kinematics__request

            from geometry_msgs.msg import Pose
            if Pose.__class__._TYPE_SUPPORT is None:
                Pose.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class InverseKinematics_Request(metaclass=Metaclass_InverseKinematics_Request):
    """Message class 'InverseKinematics_Request'."""

    __slots__ = [
        '_pose',
    ]

    _fields_and_field_types = {
        'pose': 'geometry_msgs/Pose',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Pose'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from geometry_msgs.msg import Pose
        self.pose = kwargs.get('pose', Pose())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.pose != other.pose:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def pose(self):
        """Message field 'pose'."""
        return self._pose

    @pose.setter
    def pose(self, value):
        if __debug__:
            from geometry_msgs.msg import Pose
            assert \
                isinstance(value, Pose), \
                "The 'pose' field must be a sub message of type 'Pose'"
        self._pose = value


# Import statements for member types

# already imported above
# import builtins

import math  # noqa: E402, I100

# already imported above
# import rosidl_parser.definition


class Metaclass_InverseKinematics_Response(type):
    """Metaclass of message 'InverseKinematics_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('openmx_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'openmx_interfaces.srv.InverseKinematics_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__inverse_kinematics__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__inverse_kinematics__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__inverse_kinematics__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__inverse_kinematics__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__inverse_kinematics__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class InverseKinematics_Response(metaclass=Metaclass_InverseKinematics_Response):
    """Message class 'InverseKinematics_Response'."""

    __slots__ = [
        '_success',
        '_message',
        '_theta1',
        '_theta2',
        '_theta3',
        '_theta4',
        '_theta1_alt',
        '_theta2_alt',
        '_theta3_alt',
        '_theta4_alt',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'theta1': 'double',
        'theta2': 'double',
        'theta3': 'double',
        'theta4': 'double',
        'theta1_alt': 'double',
        'theta2_alt': 'double',
        'theta3_alt': 'double',
        'theta4_alt': 'double',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        self.theta1 = kwargs.get('theta1', float())
        self.theta2 = kwargs.get('theta2', float())
        self.theta3 = kwargs.get('theta3', float())
        self.theta4 = kwargs.get('theta4', float())
        self.theta1_alt = kwargs.get('theta1_alt', float())
        self.theta2_alt = kwargs.get('theta2_alt', float())
        self.theta3_alt = kwargs.get('theta3_alt', float())
        self.theta4_alt = kwargs.get('theta4_alt', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.theta1 != other.theta1:
            return False
        if self.theta2 != other.theta2:
            return False
        if self.theta3 != other.theta3:
            return False
        if self.theta4 != other.theta4:
            return False
        if self.theta1_alt != other.theta1_alt:
            return False
        if self.theta2_alt != other.theta2_alt:
            return False
        if self.theta3_alt != other.theta3_alt:
            return False
        if self.theta4_alt != other.theta4_alt:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def theta1(self):
        """Message field 'theta1'."""
        return self._theta1

    @theta1.setter
    def theta1(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta1' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta1' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta1 = value

    @builtins.property
    def theta2(self):
        """Message field 'theta2'."""
        return self._theta2

    @theta2.setter
    def theta2(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta2' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta2' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta2 = value

    @builtins.property
    def theta3(self):
        """Message field 'theta3'."""
        return self._theta3

    @theta3.setter
    def theta3(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta3' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta3' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta3 = value

    @builtins.property
    def theta4(self):
        """Message field 'theta4'."""
        return self._theta4

    @theta4.setter
    def theta4(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta4' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta4' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta4 = value

    @builtins.property
    def theta1_alt(self):
        """Message field 'theta1_alt'."""
        return self._theta1_alt

    @theta1_alt.setter
    def theta1_alt(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta1_alt' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta1_alt' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta1_alt = value

    @builtins.property
    def theta2_alt(self):
        """Message field 'theta2_alt'."""
        return self._theta2_alt

    @theta2_alt.setter
    def theta2_alt(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta2_alt' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta2_alt' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta2_alt = value

    @builtins.property
    def theta3_alt(self):
        """Message field 'theta3_alt'."""
        return self._theta3_alt

    @theta3_alt.setter
    def theta3_alt(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta3_alt' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta3_alt' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta3_alt = value

    @builtins.property
    def theta4_alt(self):
        """Message field 'theta4_alt'."""
        return self._theta4_alt

    @theta4_alt.setter
    def theta4_alt(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'theta4_alt' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'theta4_alt' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._theta4_alt = value


class Metaclass_InverseKinematics(type):
    """Metaclass of service 'InverseKinematics'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('openmx_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'openmx_interfaces.srv.InverseKinematics')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__inverse_kinematics

            from openmx_interfaces.srv import _inverse_kinematics
            if _inverse_kinematics.Metaclass_InverseKinematics_Request._TYPE_SUPPORT is None:
                _inverse_kinematics.Metaclass_InverseKinematics_Request.__import_type_support__()
            if _inverse_kinematics.Metaclass_InverseKinematics_Response._TYPE_SUPPORT is None:
                _inverse_kinematics.Metaclass_InverseKinematics_Response.__import_type_support__()


class InverseKinematics(metaclass=Metaclass_InverseKinematics):
    from openmx_interfaces.srv._inverse_kinematics import InverseKinematics_Request as Request
    from openmx_interfaces.srv._inverse_kinematics import InverseKinematics_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
