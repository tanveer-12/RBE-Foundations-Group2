#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import math

from openmx_interfaces.srv import InverseKinematics


class IKServer(Node):

    def __init__(self):
        super().__init__('ik_server')
        self.srv = self.create_service(InverseKinematics, 'inverse_kinematics', self.compute_ik_callback)
        self.get_logger().info('Inverse Kinematics Service Server started.')

    def compute_ik_callback(self, request, response):
        x = request.pose.position.x
        y = request.pose.position.y
        z = request.pose.position.z

        # === Your IK math goes here ===
        # Example based on your earlier code
        try:
            A = math.sqrt(x**2 + y**2)
            B = z + 37.074
            R1 = 130.23
            R2 = 124
            alpha = math.radians(10.62)
            M = math.sqrt(A**2 + B**2)
            K = (A**2 + B**2 + R1**2 - R2**2) / (2 * R1)
            phi = math.atan2(B, A)

            u = math.asin(K / M) - phi
            v = math.atan2(R1 * math.cos(u) - B, A - R1 * math.sin(u))

            q2 = u - alpha
            q3 = v - u + alpha
            q4 = math.radians(90) - q2 - q3
            q1 = math.atan2(y, x)

            # Convert to degrees
            response.theta1 = math.degrees(q1)
            response.theta2 = math.degrees(q2)
            response.theta3 = math.degrees(q3)
            response.theta4 = math.degrees(q4)

            response.success = True
            response.message = 'IK solution computed successfully.'

        except Exception as e:
            response.success = False
            response.message = f'IK computation failed: {e}'

        return response


def main(args=None):
    rclpy.init(args=args)
    node = IKServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

